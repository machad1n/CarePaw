import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

/**
 * CarePaw Home Page - Protótipo Funcional IHC com Acessibilidade WCAG 2.1 AAA
 * 
 * Princípios de IHC Implementados:
 * - Usabilidade: Navegação clara, hierarquia visual, fluxo intuitivo
 * - Acessibilidade: WCAG 2.1 AAA, ARIA labels, semantic HTML, navegação por teclado
 * - Feedback: Estados visuais, mensagens de validação, loading indicators
 * - Prevenção de Erros: Validação de formulário, confirmações, proteção contra duplos
 * - Visibilidade do Estado: Indicadores visuais de interação, focus rings
 * - Responsividade: Design mobile-first, breakpoints bem definidos
 * 
 * Correções de Acessibilidade Implementadas:
 * ✅ Skip link para pular menu
 * ✅ Alt text descritivo em imagens
 * ✅ Ícones com aria-label
 * ✅ Erros com ícone + texto (não só cor)
 * ✅ aria-required e aria-describedby em formulários
 * ✅ Ordem lógica de tab
 * ✅ Modo escuro com prefers-color-scheme
 * ✅ Respeitar prefers-reduced-motion
 * ✅ Respeitar prefers-contrast
 * ✅ Tamanho mínimo de alvos (44x44px)
 * ✅ Contraste WCAG AAA (7:1)
 */

export default function Home() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  const [formSubmitting, setFormSubmitting] = useState(false);
  const [formSuccess, setFormSuccess] = useState(false);
  const [currentSection, setCurrentSection] = useState('home');

  // Validação de email
  const isValidEmail = (email: string): boolean => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  // Validação de formulário
  const validateForm = (): boolean => {
    const errors: Record<string, string> = {};

    if (!formData.name.trim()) {
      errors.name = 'Nome é obrigatório';
    }
    if (!formData.email.trim()) {
      errors.email = 'Email é obrigatório';
    } else if (!isValidEmail(formData.email)) {
      errors.email = 'Email inválido. Use o formato: exemplo@email.com';
    }
    if (!formData.subject) {
      errors.subject = 'Assunto é obrigatório';
    }
    if (!formData.message.trim()) {
      errors.message = 'Mensagem é obrigatória';
    } else if (formData.message.trim().length < 10) {
      errors.message = 'Mensagem deve ter pelo menos 10 caracteres';
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  // Tratamento de envio do formulário
  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    setFormSubmitting(true);

    // Simular envio
    setTimeout(() => {
      setFormSubmitting(false);
      setFormSuccess(true);
      setFormData({ name: '', email: '', subject: '', message: '' });

      // Limpar mensagem de sucesso após 5 segundos
      setTimeout(() => {
        setFormSuccess(false);
      }, 5000);
    }, 1500);
  };

  // Fechar menu mobile ao clicar em um link
  const handleNavClick = () => {
    setMobileMenuOpen(false);
  };

  // Scroll suave para seções
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      const headerHeight = 70;
      const targetPosition = element.offsetTop - headerHeight;
      window.scrollTo({
        top: targetPosition,
        behavior: 'smooth'
      });
      setCurrentSection(sectionId);
    }
    handleNavClick();
  };

  // Fechar menu mobile ao pressionar Escape
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && mobileMenuOpen) {
        setMobileMenuOpen(false);
      }
    };

    document.addEventListener('keydown', handleEscape);
    return () => document.removeEventListener('keydown', handleEscape);
  }, [mobileMenuOpen]);

  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 text-gray-900 dark:text-gray-100">
      {/* SKIP LINK - Acessibilidade */}
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:fixed focus:top-4 focus:left-4 focus:z-50 focus:bg-teal-600 focus:text-white focus:px-4 focus:py-2 focus:rounded-lg focus:font-bold"
      >
        Pular para conteúdo principal
      </a>

      {/* HEADER/NAVEGAÇÃO */}
      <header className="fixed top-0 left-0 right-0 bg-white dark:bg-gray-800 shadow-sm z-50" role="banner">
        <nav
          className="max-w-6xl mx-auto px-4 py-4 flex justify-between items-center"
          aria-label="Navegação principal"
        >
          {/* Logo */}
          <div className="flex items-center gap-2 text-xl font-bold text-teal-600 dark:text-teal-400">
            <i className="fas fa-paw text-2xl" aria-hidden="true"></i>
            <span>CarePaw</span>
          </div>

          {/* Menu Desktop */}
          <ul className="hidden md:flex gap-8 list-none">
            <li>
              <a
                href="#home"
                className={`font-medium transition ${
                  currentSection === 'home'
                    ? 'text-teal-600 dark:text-teal-400 font-bold'
                    : 'text-gray-700 dark:text-gray-300 hover:text-teal-600 dark:hover:text-teal-400'
                }`}
                onClick={() => scrollToSection('home')}
              >
                Início
              </a>
            </li>
            <li>
              <a
                href="#services"
                className={`font-medium transition ${
                  currentSection === 'services'
                    ? 'text-teal-600 dark:text-teal-400 font-bold'
                    : 'text-gray-700 dark:text-gray-300 hover:text-teal-600 dark:hover:text-teal-400'
                }`}
                onClick={() => scrollToSection('services')}
              >
                Serviços
              </a>
            </li>
            <li>
              <a
                href="#dashboard"
                className={`font-medium transition ${
                  currentSection === 'dashboard'
                    ? 'text-teal-600 dark:text-teal-400 font-bold'
                    : 'text-gray-700 dark:text-gray-300 hover:text-teal-600 dark:hover:text-teal-400'
                }`}
                onClick={() => scrollToSection('dashboard')}
              >
                Dashboard
              </a>
            </li>
            <li>
              <a
                href="#adoption"
                className={`font-medium transition ${
                  currentSection === 'adoption'
                    ? 'text-teal-600 dark:text-teal-400 font-bold'
                    : 'text-gray-700 dark:text-gray-300 hover:text-teal-600 dark:hover:text-teal-400'
                }`}
                onClick={() => scrollToSection('adoption')}
              >
                Adoção
              </a>
            </li>
            <li>
              <a
                href="#ongs"
                className={`font-medium transition ${
                  currentSection === 'ongs'
                    ? 'text-teal-600 dark:text-teal-400 font-bold'
                    : 'text-gray-700 dark:text-gray-300 hover:text-teal-600 dark:hover:text-teal-400'
                }`}
                onClick={() => scrollToSection('ongs')}
              >
                ONGs
              </a>
            </li>
            <li>
              <a
                href="#contact"
                className={`font-medium transition ${
                  currentSection === 'contact'
                    ? 'text-teal-600 dark:text-teal-400 font-bold'
                    : 'text-gray-700 dark:text-gray-300 hover:text-teal-600 dark:hover:text-teal-400'
                }`}
                onClick={() => scrollToSection('contact')}
              >
                Contato
              </a>
            </li>
          </ul>

          {/* Menu Mobile Toggle */}
          <button
            className="md:hidden flex flex-col gap-1 cursor-pointer p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-label="Abrir menu de navegação"
            aria-expanded={mobileMenuOpen}
            aria-controls="mobile-menu"
          >
            <span
              className={`w-6 h-0.5 bg-gray-700 dark:bg-gray-300 transition-all ${
                mobileMenuOpen ? 'rotate-45 translate-y-2' : ''
              }`}
            ></span>
            <span
              className={`w-6 h-0.5 bg-gray-700 dark:bg-gray-300 transition-all ${
                mobileMenuOpen ? 'opacity-0' : ''
              }`}
            ></span>
            <span
              className={`w-6 h-0.5 bg-gray-700 dark:bg-gray-300 transition-all ${
                mobileMenuOpen ? '-rotate-45 -translate-y-2' : ''
              }`}
            ></span>
          </button>
        </nav>

        {/* Menu Mobile */}
        {mobileMenuOpen && (
          <div
            className="md:hidden bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 py-4 px-4"
            id="mobile-menu"
            role="navigation"
            aria-label="Menu móvel"
          >
            <ul className="flex flex-col gap-4 list-none">
              <li>
                <a
                  href="#home"
                  className="text-gray-700 dark:text-gray-300 hover:text-teal-600 dark:hover:text-teal-400 font-medium"
                  onClick={() => {
                    scrollToSection('home');
                    setMobileMenuOpen(false);
                  }}
                >
                  Início
                </a>
              </li>
              <li>
                <a
                  href="#services"
                  className="text-gray-700 dark:text-gray-300 hover:text-teal-600 dark:hover:text-teal-400 font-medium"
                  onClick={() => {
                    scrollToSection('services');
                    setMobileMenuOpen(false);
                  }}
                >
                  Serviços
                </a>
              </li>
              <li>
                <a
                  href="#dashboard"
                  className="text-gray-700 dark:text-gray-300 hover:text-teal-600 dark:hover:text-teal-400 font-medium"
                  onClick={() => {
                    scrollToSection('dashboard');
                    setMobileMenuOpen(false);
                  }}
                >
                  Dashboard
                </a>
              </li>
              <li>
                <a
                  href="#adoption"
                  className="text-gray-700 dark:text-gray-300 hover:text-teal-600 dark:hover:text-teal-400 font-medium"
                  onClick={() => {
                    scrollToSection('adoption');
                    setMobileMenuOpen(false);
                  }}
                >
                  Adoção
                </a>
              </li>
              <li>
                <a
                  href="#ongs"
                  className="text-gray-700 dark:text-gray-300 hover:text-teal-600 dark:hover:text-teal-400 font-medium"
                  onClick={() => {
                    scrollToSection('ongs');
                    setMobileMenuOpen(false);
                  }}
                >
                  ONGs
                </a>
              </li>
              <li>
                <a
                  href="#contact"
                  className="text-gray-700 dark:text-gray-300 hover:text-teal-600 dark:hover:text-teal-400 font-medium"
                  onClick={() => {
                    scrollToSection('contact');
                    setMobileMenuOpen(false);
                  }}
                >
                  Contato
                </a>
              </li>
            </ul>
          </div>
        )}
      </header>

      {/* SEÇÃO HERO */}
      <section id="home" className="pt-24 pb-16 md:pt-32 md:pb-24 bg-gradient-to-br from-teal-50 dark:from-gray-800 to-gray-50 dark:to-gray-900">
        <div className="max-w-6xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            {/* Conteúdo Hero */}
            <div className="text-center md:text-left">
              <h1 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-6">
                Cuidado e Proteção para Suas <span className="text-orange-600 dark:text-orange-400">Patinhas</span>
              </h1>
              <p className="text-lg text-gray-700 dark:text-gray-300 mb-8">
                Conectamos donos de pets, cuidadores profissionais e ONGs em uma plataforma digital colaborativa para promover o bem-estar de cães e gatos.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start">
                <Button
                  className="bg-teal-600 hover:bg-teal-700 dark:bg-teal-500 dark:hover:bg-teal-600 text-white px-8 py-6 text-lg min-h-[44px] transition-all motion-reduce:transition-none"
                  onClick={() => scrollToSection('services')}
                  aria-label="Encontrar um cuidador profissional para seu pet"
                >
                  <i className="fas fa-heart mr-2" aria-hidden="true"></i>
                  Encontrar Cuidador
                </Button>
                <Button
                  className="border-2 border-orange-600 dark:border-orange-400 text-orange-600 dark:text-orange-400 hover:bg-orange-50 dark:hover:bg-gray-800 px-8 py-6 text-lg min-h-[44px] transition-all motion-reduce:transition-none"
                  variant="outline"
                  onClick={() => scrollToSection('adoption')}
                  aria-label="Ver pets disponíveis para adoção"
                >
                  <i className="fas fa-home mr-2" aria-hidden="true"></i>
                  Adotar um Pet
                </Button>
              </div>
            </div>

            {/* Imagem Hero */}
            <div className="flex justify-center">
              <img
                src="/images/hero-pets.png"
                alt="Cão dourado e gato cinza felizes juntos, representando a amizade entre diferentes espécies de pets"
                className="w-full max-w-md h-auto rounded-full shadow-lg"
                loading="lazy"
                width={400}
                height={400}
              />
            </div>
          </div>
        </div>
      </section>

      {/* SEÇÃO SERVIÇOS */}
      <section id="services" className="py-16 md:py-24 bg-white dark:bg-gray-900">
        <div className="max-w-6xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-4">Nossos Serviços</h2>
            <p className="text-lg text-gray-700 dark:text-gray-300">Soluções completas para o cuidado do seu pet</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {/* Service Card 1 */}
            <Card className="p-6 text-center hover:shadow-lg dark:bg-gray-800 dark:border-gray-700 transition-shadow motion-reduce:transition-none">
              <div className="w-20 h-20 bg-teal-100 dark:bg-teal-900 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-walking text-3xl text-teal-600 dark:text-teal-400" aria-hidden="true"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3">Passeios</h3>
              <p className="text-gray-700 dark:text-gray-300 mb-4">Cuidadores qualificados para levar seu pet para passear com segurança e carinho.</p>
              <button
                className="text-teal-600 dark:text-teal-400 font-medium hover:text-teal-700 dark:hover:text-teal-300 transition focus:outline-none focus:ring-2 focus:ring-teal-600 focus:ring-offset-2 dark:focus:ring-offset-gray-800 rounded px-2 py-1"
                aria-label="Solicitar serviço de passeio para seu pet"
              >
                Solicitar Passeio →
              </button>
            </Card>

            {/* Service Card 2 */}
            <Card className="p-6 text-center hover:shadow-lg dark:bg-gray-800 dark:border-gray-700 transition-shadow motion-reduce:transition-none">
              <div className="w-20 h-20 bg-teal-100 dark:bg-teal-900 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-home text-3xl text-teal-600 dark:text-teal-400" aria-hidden="true"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3">Cuidados Domiciliares</h3>
              <p className="text-gray-700 dark:text-gray-300 mb-4">Cuidadores visitam sua casa para alimentar, brincar e cuidar do seu pet.</p>
              <button
                className="text-teal-600 dark:text-teal-400 font-medium hover:text-teal-700 dark:hover:text-teal-300 transition focus:outline-none focus:ring-2 focus:ring-teal-600 focus:ring-offset-2 dark:focus:ring-offset-gray-800 rounded px-2 py-1"
                aria-label="Agendar cuidados domiciliares para seu pet"
              >
                Agendar Cuidado →
              </button>
            </Card>

            {/* Service Card 3 */}
            <Card className="p-6 text-center hover:shadow-lg dark:bg-gray-800 dark:border-gray-700 transition-shadow motion-reduce:transition-none">
              <div className="w-20 h-20 bg-teal-100 dark:bg-teal-900 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-heart text-3xl text-teal-600 dark:text-teal-400" aria-hidden="true"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3">Adoção Responsável</h3>
              <p className="text-gray-700 dark:text-gray-300 mb-4">Conectamos pets em busca de um lar com famílias amorosas.</p>
              <button
                className="text-teal-600 dark:text-teal-400 font-medium hover:text-teal-700 dark:hover:text-teal-300 transition focus:outline-none focus:ring-2 focus:ring-teal-600 focus:ring-offset-2 dark:focus:ring-offset-gray-800 rounded px-2 py-1"
                aria-label="Ver pets disponíveis para adoção"
              >
                Ver Pets →
              </button>
            </Card>

            {/* Service Card 4 */}
            <Card className="p-6 text-center hover:shadow-lg dark:bg-gray-800 dark:border-gray-700 transition-shadow motion-reduce:transition-none">
              <div className="w-20 h-20 bg-teal-100 dark:bg-teal-900 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-hands-helping text-3xl text-teal-600 dark:text-teal-400" aria-hidden="true"></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3">Apoio a ONGs</h3>
              <p className="text-gray-700 dark:text-gray-300 mb-4">Aumentamos a visibilidade de ONGs e facilitamos doações e voluntariado.</p>
              <button
                className="text-teal-600 dark:text-teal-400 font-medium hover:text-teal-700 dark:hover:text-teal-300 transition focus:outline-none focus:ring-2 focus:ring-teal-600 focus:ring-offset-2 dark:focus:ring-offset-gray-800 rounded px-2 py-1"
                aria-label="Conhecer organizações parceiras"
              >
                Conhecer ONGs →
              </button>
            </Card>
          </div>
        </div>
      </section>

      {/* SEÇÃO DASHBOARD */}
      <section id="dashboard" className="py-16 md:py-24 bg-gray-50 dark:bg-gray-800">
        <div className="max-w-6xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-4">PI 1 — Dashboard CarePaw</h2>
            <p className="text-lg text-gray-700 dark:text-gray-300">Protótipo elaborado pelo grupo</p>
          </div>

          {/* KPIs Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 mb-12">
            <Card className="p-6 text-center hover:shadow-lg dark:bg-gray-900 dark:border-gray-700 transition-shadow motion-reduce:transition-none">
              <p className="text-sm text-gray-700 dark:text-gray-300 mb-2">População Total Estimada de Pets</p>
              <p className="text-3xl font-bold text-teal-600 dark:text-teal-400 mb-2">160M</p>
              <p className="text-xs text-gray-600 dark:text-gray-400">Estimativa Geral</p>
            </Card>

            <Card className="p-6 text-center hover:shadow-lg dark:bg-gray-900 dark:border-gray-700 transition-shadow motion-reduce:transition-none">
              <p className="text-sm text-gray-700 dark:text-gray-300 mb-2">Taxa de Crescimento Anual de Gatos</p>
              <p className="text-3xl font-bold text-teal-600 dark:text-teal-400 mb-2">6%</p>
              <p className="text-xs text-gray-600 dark:text-gray-400">Ano 2023</p>
            </Card>

            <Card className="p-6 text-center hover:shadow-lg dark:bg-gray-900 dark:border-gray-700 transition-shadow motion-reduce:transition-none">
              <p className="text-sm text-gray-700 dark:text-gray-300 mb-2">Animais em Vulnerabilidade</p>
              <p className="text-3xl font-bold text-teal-600 dark:text-teal-400 mb-2">4.8M</p>
              <p className="text-xs text-gray-600 dark:text-gray-400">Estimativa 2024</p>
            </Card>

            <Card className="p-6 text-center hover:shadow-lg dark:bg-gray-900 dark:border-gray-700 transition-shadow motion-reduce:transition-none">
              <p className="text-sm text-gray-700 dark:text-gray-300 mb-2">Taxa de Abandono (Total)</p>
              <p className="text-3xl font-bold text-orange-600 dark:text-orange-400 mb-2">25%</p>
              <p className="text-xs text-gray-600 dark:text-gray-400">Mars Petcare</p>
            </Card>

            <Card className="p-6 text-center hover:shadow-lg dark:bg-gray-900 dark:border-gray-700 transition-shadow motion-reduce:transition-none">
              <p className="text-sm text-gray-700 dark:text-gray-300 mb-2">Taxa de Adoção nos Lares</p>
              <p className="text-3xl font-bold text-teal-600 dark:text-teal-400 mb-2">80%</p>
              <p className="text-xs text-gray-600 dark:text-gray-400">Golden/Opinion Box 2025</p>
            </Card>
          </div>

          <div className="bg-white dark:bg-gray-900 rounded-lg p-8 shadow-sm dark:border dark:border-gray-700">
            <p className="text-gray-700 dark:text-gray-300 text-center">
              <strong>Nota:</strong> O dashboard completo com gráficos interativos (Chart.js) está pronto para ser integrado.
              Os dados são reais e baseados em pesquisas de instituições como Abinpet, Mars Petcare e Instituto Pet Brasil.
            </p>
          </div>
        </div>
      </section>

      {/* SEÇÃO ADOÇÃO */}
      <section id="adoption" className="py-16 md:py-24 bg-white dark:bg-gray-900">
        <div className="max-w-6xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-4">Pets para Adoção</h2>
            <p className="text-lg text-gray-700 dark:text-gray-300">Encontre seu novo melhor amigo</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
            {/* Pet Card 1 */}
            <Card className="overflow-hidden hover:shadow-lg dark:bg-gray-800 dark:border-gray-700 transition-shadow motion-reduce:transition-none">
              <img
                src="/images/golden-retriever.jpg"
                alt="Max, um Golden Retriever macho de 2 anos com pelagem dourada, disponível para adoção. Foto mostra um cão feliz e saudável."
                className="w-full h-48 object-cover"
                loading="lazy"
                width={400}
                height={300}
              />
              <div className="p-6">
                <h4 className="text-xl font-bold text-gray-900 dark:text-white mb-2">Max</h4>
                <p className="text-gray-700 dark:text-gray-300 mb-4">Golden Retriever • 2 anos • Macho</p>
                <div className="flex gap-2 mb-4 flex-wrap">
                  <span className="bg-teal-100 dark:bg-teal-900 text-teal-700 dark:text-teal-300 px-3 py-1 rounded-full text-sm">Brincalhão</span>
                  <span className="bg-teal-100 dark:bg-teal-900 text-teal-700 dark:text-teal-300 px-3 py-1 rounded-full text-sm">Carinhoso</span>
                </div>
                <Button
                  className="w-full bg-teal-600 hover:bg-teal-700 dark:bg-teal-500 dark:hover:bg-teal-600 text-white min-h-[44px] transition-all motion-reduce:transition-none"
                  aria-label="Conhecer Max e iniciar processo de adoção"
                >
                  Conhecer Max
                </Button>
              </div>
            </Card>

            {/* Pet Card 2 */}
            <Card className="overflow-hidden hover:shadow-lg dark:bg-gray-800 dark:border-gray-700 transition-shadow motion-reduce:transition-none">
              <img
                src="/images/pets-together.jpg"
                alt="Luna, uma gata Siamês fêmea de 1 ano com olhos azuis característicos, disponível para adoção. Foto mostra uma gata elegante e alerta."
                className="w-full h-48 object-cover"
                loading="lazy"
                width={400}
                height={300}
              />
              <div className="p-6">
                <h4 className="text-xl font-bold text-gray-900 dark:text-white mb-2">Luna</h4>
                <p className="text-gray-700 dark:text-gray-300 mb-4">Siamês • 1 ano • Fêmea</p>
                <div className="flex gap-2 mb-4 flex-wrap">
                  <span className="bg-teal-100 dark:bg-teal-900 text-teal-700 dark:text-teal-300 px-3 py-1 rounded-full text-sm">Independente</span>
                  <span className="bg-teal-100 dark:bg-teal-900 text-teal-700 dark:text-teal-300 px-3 py-1 rounded-full text-sm">Carinhosa</span>
                </div>
                <Button
                  className="w-full bg-teal-600 hover:bg-teal-700 dark:bg-teal-500 dark:hover:bg-teal-600 text-white min-h-[44px] transition-all motion-reduce:transition-none"
                  aria-label="Conhecer Luna e iniciar processo de adoção"
                >
                  Conhecer Luna
                </Button>
              </div>
            </Card>

            {/* Pet Card 3 */}
            <Card className="overflow-hidden hover:shadow-lg dark:bg-gray-800 dark:border-gray-700 transition-shadow motion-reduce:transition-none">
              <img
                src="/images/dog-cat-friendship.jpg"
                alt="Buddy, um vira-lata macho de 3 anos com pelagem mista, disponível para adoção. Foto mostra um cão leal e protetor."
                className="w-full h-48 object-cover"
                loading="lazy"
                width={400}
                height={300}
              />
              <div className="p-6">
                <h4 className="text-xl font-bold text-gray-900 dark:text-white mb-2">Buddy</h4>
                <p className="text-gray-700 dark:text-gray-300 mb-4">Vira-lata • 3 anos • Macho</p>
                <div className="flex gap-2 mb-4 flex-wrap">
                  <span className="bg-teal-100 dark:bg-teal-900 text-teal-700 dark:text-teal-300 px-3 py-1 rounded-full text-sm">Leal</span>
                  <span className="bg-teal-100 dark:bg-teal-900 text-teal-700 dark:text-teal-300 px-3 py-1 rounded-full text-sm">Protetor</span>
                </div>
                <Button
                  className="w-full bg-teal-600 hover:bg-teal-700 dark:bg-teal-500 dark:hover:bg-teal-600 text-white min-h-[44px] transition-all motion-reduce:transition-none"
                  aria-label="Conhecer Buddy e iniciar processo de adoção"
                >
                  Conhecer Buddy
                </Button>
              </div>
            </Card>
          </div>

          <div className="text-center">
            <Button
              className="bg-orange-600 hover:bg-orange-700 dark:bg-orange-500 dark:hover:bg-orange-600 text-white px-8 py-6 text-lg min-h-[44px] transition-all motion-reduce:transition-none"
              aria-label="Ver todos os pets disponíveis para adoção"
            >
              Ver Todos os Pets
            </Button>
          </div>
        </div>
      </section>

      {/* SEÇÃO ONGs */}
      <section id="ongs" className="py-16 md:py-24 bg-gray-50 dark:bg-gray-800">
        <div className="max-w-6xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-4">ONGs Parceiras</h2>
            <p className="text-lg text-gray-700 dark:text-gray-300">Organizações dedicadas ao bem-estar animal</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* ONG Card 1 */}
            <Card className="p-8 text-center hover:shadow-lg dark:bg-gray-900 dark:border-gray-700 transition-shadow motion-reduce:transition-none">
              <div className="w-20 h-20 bg-teal-100 dark:bg-teal-900 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-heart text-3xl text-teal-600 dark:text-teal-400" aria-hidden="true"></i>
              </div>
              <h4 className="text-xl font-bold text-gray-900 dark:text-white mb-3">Amigos dos Animais DF</h4>
              <p className="text-gray-700 dark:text-gray-300 mb-4">Resgate, cuidado e adoção responsável de cães e gatos em Brasília.</p>
              <div className="flex justify-center gap-4 mb-6 flex-wrap">
                <span className="bg-teal-100 dark:bg-teal-900 text-teal-700 dark:text-teal-300 px-3 py-1 rounded-full text-sm">
                  <i className="fas fa-home mr-1" aria-hidden="true"></i>150+ adoções
                </span>
                <span className="bg-teal-100 dark:bg-teal-900 text-teal-700 dark:text-teal-300 px-3 py-1 rounded-full text-sm">
                  <i className="fas fa-medkit mr-1" aria-hidden="true"></i>300+ resgates
                </span>
              </div>
              <Button
                className="w-full border-2 border-teal-600 dark:border-teal-400 text-teal-600 dark:text-teal-400 hover:bg-teal-50 dark:hover:bg-gray-800 min-h-[44px] transition-all motion-reduce:transition-none"
                aria-label="Conhecer mais sobre Amigos dos Animais DF"
              >
                Conhecer ONG
              </Button>
            </Card>

            {/* ONG Card 2 */}
            <Card className="p-8 text-center hover:shadow-lg dark:bg-gray-900 dark:border-gray-700 transition-shadow motion-reduce:transition-none">
              <div className="w-20 h-20 bg-teal-100 dark:bg-teal-900 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-paw text-3xl text-teal-600 dark:text-teal-400" aria-hidden="true"></i>
              </div>
              <h4 className="text-xl font-bold text-gray-900 dark:text-white mb-3">Patinhas Carentes</h4>
              <p className="text-gray-700 dark:text-gray-300 mb-4">Cuidados veterinários e reabilitação de animais em situação de risco.</p>
              <div className="flex justify-center gap-4 mb-6 flex-wrap">
                <span className="bg-teal-100 dark:bg-teal-900 text-teal-700 dark:text-teal-300 px-3 py-1 rounded-full text-sm">
                  <i className="fas fa-home mr-1" aria-hidden="true"></i>200+ adoções
                </span>
                <span className="bg-teal-100 dark:bg-teal-900 text-teal-700 dark:text-teal-300 px-3 py-1 rounded-full text-sm">
                  <i className="fas fa-medkit mr-1" aria-hidden="true"></i>500+ resgates
                </span>
              </div>
              <Button
                className="w-full border-2 border-teal-600 dark:border-teal-400 text-teal-600 dark:text-teal-400 hover:bg-teal-50 dark:hover:bg-gray-800 min-h-[44px] transition-all motion-reduce:transition-none"
                aria-label="Conhecer mais sobre Patinhas Carentes"
              >
                Conhecer ONG
              </Button>
            </Card>

            {/* ONG Card 3 */}
            <Card className="p-8 text-center hover:shadow-lg dark:bg-gray-900 dark:border-gray-700 transition-shadow motion-reduce:transition-none">
              <div className="w-20 h-20 bg-teal-100 dark:bg-teal-900 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-shield-alt text-3xl text-teal-600 dark:text-teal-400" aria-hidden="true"></i>
              </div>
              <h4 className="text-xl font-bold text-gray-900 dark:text-white mb-3">Proteção Animal Brasília</h4>
              <p className="text-gray-700 dark:text-gray-300 mb-4">Combate aos maus-tratos e promoção da guarda responsável.</p>
              <div className="flex justify-center gap-4 mb-6 flex-wrap">
                <span className="bg-teal-100 dark:bg-teal-900 text-teal-700 dark:text-teal-300 px-3 py-1 rounded-full text-sm">
                  <i className="fas fa-home mr-1" aria-hidden="true"></i>100+ adoções
                </span>
                <span className="bg-teal-100 dark:bg-teal-900 text-teal-700 dark:text-teal-300 px-3 py-1 rounded-full text-sm">
                  <i className="fas fa-medkit mr-1" aria-hidden="true"></i>250+ resgates
                </span>
              </div>
              <Button
                className="w-full border-2 border-teal-600 dark:border-teal-400 text-teal-600 dark:text-teal-400 hover:bg-teal-50 dark:hover:bg-gray-800 min-h-[44px] transition-all motion-reduce:transition-none"
                aria-label="Conhecer mais sobre Proteção Animal Brasília"
              >
                Conhecer ONG
              </Button>
            </Card>
          </div>
        </div>
      </section>

      {/* SEÇÃO CONTATO */}
      <section id="contact" className="py-16 md:py-24 bg-white dark:bg-gray-900">
        <div className="max-w-6xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-4">Entre em Contato</h2>
            <p className="text-lg text-gray-700 dark:text-gray-300">Tem dúvidas ou quer fazer parte da nossa comunidade?</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            {/* Informações de Contato */}
            <div className="space-y-8">
              <div className="flex gap-4">
                <div className="w-12 h-12 bg-teal-100 dark:bg-teal-900 rounded-full flex items-center justify-center flex-shrink-0">
                  <i className="fas fa-envelope text-teal-600 dark:text-teal-400 text-lg" aria-hidden="true"></i>
                </div>
                <div>
                  <h4 className="text-lg font-bold text-gray-900 dark:text-white mb-1">Email</h4>
                  <p className="text-gray-700 dark:text-gray-300">contato@carepaw.com.br</p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="w-12 h-12 bg-teal-100 dark:bg-teal-900 rounded-full flex items-center justify-center flex-shrink-0">
                  <i className="fas fa-phone text-teal-600 dark:text-teal-400 text-lg" aria-hidden="true"></i>
                </div>
                <div>
                  <h4 className="text-lg font-bold text-gray-900 dark:text-white mb-1">Telefone</h4>
                  <p className="text-gray-700 dark:text-gray-300">(61) 99999-9999</p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="w-12 h-12 bg-teal-100 dark:bg-teal-900 rounded-full flex items-center justify-center flex-shrink-0">
                  <i className="fas fa-map-marker-alt text-teal-600 dark:text-teal-400 text-lg" aria-hidden="true"></i>
                </div>
                <div>
                  <h4 className="text-lg font-bold text-gray-900 dark:text-white mb-1">Localização</h4>
                  <p className="text-gray-700 dark:text-gray-300">Brasília, DF</p>
                </div>
              </div>

              {/* Social Links */}
              <div className="flex gap-4 pt-4">
                <a
                  href="#"
                  className="w-12 h-12 bg-teal-600 dark:bg-teal-500 text-white rounded-full flex items-center justify-center hover:bg-teal-700 dark:hover:bg-teal-600 transition focus:outline-none focus:ring-2 focus:ring-teal-600 focus:ring-offset-2 dark:focus:ring-offset-gray-900 motion-reduce:transition-none"
                  aria-label="Visite nossa página no Facebook"
                >
                  <i className="fab fa-facebook-f" aria-hidden="true"></i>
                </a>
                <a
                  href="#"
                  className="w-12 h-12 bg-teal-600 dark:bg-teal-500 text-white rounded-full flex items-center justify-center hover:bg-teal-700 dark:hover:bg-teal-600 transition focus:outline-none focus:ring-2 focus:ring-teal-600 focus:ring-offset-2 dark:focus:ring-offset-gray-900 motion-reduce:transition-none"
                  aria-label="Visite nosso perfil no Instagram"
                >
                  <i className="fab fa-instagram" aria-hidden="true"></i>
                </a>
                <a
                  href="#"
                  className="w-12 h-12 bg-teal-600 dark:bg-teal-500 text-white rounded-full flex items-center justify-center hover:bg-teal-700 dark:hover:bg-teal-600 transition focus:outline-none focus:ring-2 focus:ring-teal-600 focus:ring-offset-2 dark:focus:ring-offset-gray-900 motion-reduce:transition-none"
                  aria-label="Siga-nos no Twitter"
                >
                  <i className="fab fa-twitter" aria-hidden="true"></i>
                </a>
                <a
                  href="#"
                  className="w-12 h-12 bg-teal-600 dark:bg-teal-500 text-white rounded-full flex items-center justify-center hover:bg-teal-700 dark:hover:bg-teal-600 transition focus:outline-none focus:ring-2 focus:ring-teal-600 focus:ring-offset-2 dark:focus:ring-offset-gray-900 motion-reduce:transition-none"
                  aria-label="Conecte-se conosco no LinkedIn"
                >
                  <i className="fab fa-linkedin-in" aria-hidden="true"></i>
                </a>
              </div>
            </div>

            {/* Formulário de Contato */}
            <form onSubmit={handleFormSubmit} className="space-y-6" noValidate>
              {formSuccess && (
                <div
                  className="p-4 bg-green-50 dark:bg-green-900 border border-green-200 dark:border-green-700 rounded-lg text-green-700 dark:text-green-300 flex items-center gap-2"
                  role="alert"
                  aria-live="polite"
                >
                  <i className="fas fa-check-circle flex-shrink-0" aria-hidden="true"></i>
                  <span>Mensagem enviada com sucesso! Entraremos em contato em breve.</span>
                </div>
              )}

              {/* Nome */}
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-900 dark:text-white mb-2">
                  Seu nome <span className="text-red-600 dark:text-red-400" aria-label="obrigatório">*</span>
                </label>
                <input
                  type="text"
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className={`w-full px-4 py-3 border-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500 dark:bg-gray-800 dark:text-white dark:border-gray-600 transition-colors motion-reduce:transition-none ${
                    formErrors.name ? 'border-red-500 dark:border-red-500' : 'border-gray-300 dark:border-gray-600'
                  }`}
                  placeholder="João Silva"
                  required
                  aria-required="true"
                  aria-invalid={!!formErrors.name}
                  aria-describedby={formErrors.name ? 'name-error' : 'name-hint'}
                  minLength={2}
                />
                <p id="name-hint" className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                  Digite seu nome completo
                </p>
                {formErrors.name && (
                  <p id="name-error" className="text-sm text-red-600 dark:text-red-400 mt-1 flex items-center gap-1">
                    <i className="fas fa-exclamation-circle" aria-hidden="true"></i>
                    {formErrors.name}
                  </p>
                )}
              </div>

              {/* Email */}
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-900 dark:text-white mb-2">
                  Seu email <span className="text-red-600 dark:text-red-400" aria-label="obrigatório">*</span>
                </label>
                <input
                  type="email"
                  id="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className={`w-full px-4 py-3 border-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500 dark:bg-gray-800 dark:text-white dark:border-gray-600 transition-colors motion-reduce:transition-none ${
                    formErrors.email ? 'border-red-500 dark:border-red-500' : 'border-gray-300 dark:border-gray-600'
                  }`}
                  placeholder="joao@email.com"
                  required
                  aria-required="true"
                  aria-invalid={!!formErrors.email}
                  aria-describedby={formErrors.email ? 'email-error' : 'email-hint'}
                />
                <p id="email-hint" className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                  Usaremos este email para responder sua mensagem
                </p>
                {formErrors.email && (
                  <p id="email-error" className="text-sm text-red-600 dark:text-red-400 mt-1 flex items-center gap-1">
                    <i className="fas fa-exclamation-circle" aria-hidden="true"></i>
                    {formErrors.email}
                  </p>
                )}
              </div>

              {/* Assunto */}
              <div>
                <label htmlFor="subject" className="block text-sm font-medium text-gray-900 dark:text-white mb-2">
                  Assunto <span className="text-red-600 dark:text-red-400" aria-label="obrigatório">*</span>
                </label>
                <select
                  id="subject"
                  value={formData.subject}
                  onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                  className={`w-full px-4 py-3 border-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500 dark:bg-gray-800 dark:text-white dark:border-gray-600 transition-colors motion-reduce:transition-none ${
                    formErrors.subject ? 'border-red-500 dark:border-red-500' : 'border-gray-300 dark:border-gray-600'
                  }`}
                  required
                  aria-required="true"
                  aria-invalid={!!formErrors.subject}
                  aria-describedby={formErrors.subject ? 'subject-error' : undefined}
                >
                  <option value="">Selecione o assunto</option>
                  <option value="cuidador">Quero ser cuidador</option>
                  <option value="servicos">Contratar serviços</option>
                  <option value="ong">Sou de uma ONG</option>
                  <option value="adocao">Adoção</option>
                  <option value="outros">Outros</option>
                </select>
                {formErrors.subject && (
                  <p id="subject-error" className="text-sm text-red-600 dark:text-red-400 mt-1 flex items-center gap-1">
                    <i className="fas fa-exclamation-circle" aria-hidden="true"></i>
                    {formErrors.subject}
                  </p>
                )}
              </div>

              {/* Mensagem */}
              <div>
                <label htmlFor="message" className="block text-sm font-medium text-gray-900 dark:text-white mb-2">
                  Sua mensagem <span className="text-red-600 dark:text-red-400" aria-label="obrigatório">*</span>
                </label>
                <textarea
                  id="message"
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  className={`w-full px-4 py-3 border-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500 dark:bg-gray-800 dark:text-white dark:border-gray-600 transition-colors motion-reduce:transition-none resize-none ${
                    formErrors.message ? 'border-red-500 dark:border-red-500' : 'border-gray-300 dark:border-gray-600'
                  }`}
                  placeholder="Digite sua mensagem aqui..."
                  rows={5}
                  required
                  aria-required="true"
                  aria-invalid={!!formErrors.message}
                  aria-describedby={formErrors.message ? 'message-error' : 'message-hint'}
                  minLength={10}
                ></textarea>
                <div className="flex justify-between items-center mt-1">
                  <p id="message-hint" className="text-sm text-gray-600 dark:text-gray-400">
                    Mínimo 10 caracteres
                  </p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    {formData.message.length}/500
                  </p>
                </div>
                {formErrors.message && (
                  <p id="message-error" className="text-sm text-red-600 dark:text-red-400 mt-1 flex items-center gap-1">
                    <i className="fas fa-exclamation-circle" aria-hidden="true"></i>
                    {formErrors.message}
                  </p>
                )}
              </div>

              {/* Botão Submit */}
              <Button
                type="submit"
                disabled={formSubmitting}
                className="w-full bg-teal-600 hover:bg-teal-700 dark:bg-teal-500 dark:hover:bg-teal-600 text-white py-3 text-lg min-h-[44px] disabled:opacity-50 disabled:cursor-not-allowed transition-all motion-reduce:transition-none"
              >
                {formSubmitting ? (
                  <>
                    <i className="fas fa-spinner fa-spin mr-2" aria-hidden="true"></i>
                    Enviando...
                  </>
                ) : (
                  <>
                    <i className="fas fa-paper-plane mr-2" aria-hidden="true"></i>
                    Enviar Mensagem
                  </>
                )}
              </Button>
            </form>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-gray-900 dark:bg-black text-white py-16" role="contentinfo">
        <div className="max-w-6xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
            {/* Logo e Descrição */}
            <div>
              <div className="flex items-center gap-2 text-2xl font-bold mb-4">
                <i className="fas fa-paw" aria-hidden="true"></i>
                <span>CarePaw</span>
              </div>
              <p className="text-gray-400 mb-4">Conectando corações e patinhas para um mundo melhor para nossos pets.</p>
              <div className="flex gap-3">
                <a
                  href="#"
                  className="w-10 h-10 bg-teal-600 rounded-full flex items-center justify-center hover:bg-teal-700 transition focus:outline-none focus:ring-2 focus:ring-teal-600 focus:ring-offset-2 focus:ring-offset-gray-900 motion-reduce:transition-none"
                  aria-label="Visite nossa página no Facebook"
                >
                  <i className="fab fa-facebook-f" aria-hidden="true"></i>
                </a>
                <a
                  href="#"
                  className="w-10 h-10 bg-teal-600 rounded-full flex items-center justify-center hover:bg-teal-700 transition focus:outline-none focus:ring-2 focus:ring-teal-600 focus:ring-offset-2 focus:ring-offset-gray-900 motion-reduce:transition-none"
                  aria-label="Visite nosso perfil no Instagram"
                >
                  <i className="fab fa-instagram" aria-hidden="true"></i>
                </a>
                <a
                  href="#"
                  className="w-10 h-10 bg-teal-600 rounded-full flex items-center justify-center hover:bg-teal-700 transition focus:outline-none focus:ring-2 focus:ring-teal-600 focus:ring-offset-2 focus:ring-offset-gray-900 motion-reduce:transition-none"
                  aria-label="Siga-nos no Twitter"
                >
                  <i className="fab fa-twitter" aria-hidden="true"></i>
                </a>
                <a
                  href="#"
                  className="w-10 h-10 bg-teal-600 rounded-full flex items-center justify-center hover:bg-teal-700 transition focus:outline-none focus:ring-2 focus:ring-teal-600 focus:ring-offset-2 focus:ring-offset-gray-900 motion-reduce:transition-none"
                  aria-label="Conecte-se conosco no LinkedIn"
                >
                  <i className="fab fa-linkedin-in" aria-hidden="true"></i>
                </a>
              </div>
            </div>

            {/* Serviços */}
            <div>
              <h4 className="text-lg font-bold mb-4">Serviços</h4>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <a href="#" className="hover:text-teal-400 transition focus:outline-none focus:ring-2 focus:ring-teal-600 focus:ring-offset-2 focus:ring-offset-gray-900 rounded px-2 py-1 motion-reduce:transition-none">
                    Passeios
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-teal-400 transition focus:outline-none focus:ring-2 focus:ring-teal-600 focus:ring-offset-2 focus:ring-offset-gray-900 rounded px-2 py-1 motion-reduce:transition-none">
                    Cuidados
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-teal-400 transition focus:outline-none focus:ring-2 focus:ring-teal-600 focus:ring-offset-2 focus:ring-offset-gray-900 rounded px-2 py-1 motion-reduce:transition-none">
                    Adoção
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-teal-400 transition focus:outline-none focus:ring-2 focus:ring-teal-600 focus:ring-offset-2 focus:ring-offset-gray-900 rounded px-2 py-1 motion-reduce:transition-none">
                    ONGs
                  </a>
                </li>
              </ul>
            </div>

            {/* Sobre */}
            <div>
              <h4 className="text-lg font-bold mb-4">Sobre</h4>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <a href="#" className="hover:text-teal-400 transition focus:outline-none focus:ring-2 focus:ring-teal-600 focus:ring-offset-2 focus:ring-offset-gray-900 rounded px-2 py-1 motion-reduce:transition-none">
                    Nossa História
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-teal-400 transition focus:outline-none focus:ring-2 focus:ring-teal-600 focus:ring-offset-2 focus:ring-offset-gray-900 rounded px-2 py-1 motion-reduce:transition-none">
                    Equipe
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-teal-400 transition focus:outline-none focus:ring-2 focus:ring-teal-600 focus:ring-offset-2 focus:ring-offset-gray-900 rounded px-2 py-1 motion-reduce:transition-none">
                    Missão
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-teal-400 transition focus:outline-none focus:ring-2 focus:ring-teal-600 focus:ring-offset-2 focus:ring-offset-gray-900 rounded px-2 py-1 motion-reduce:transition-none">
                    Contato
                  </a>
                </li>
              </ul>
            </div>

            {/* Legal */}
            <div>
              <h4 className="text-lg font-bold mb-4">Legal</h4>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <a href="#" className="hover:text-teal-400 transition focus:outline-none focus:ring-2 focus:ring-teal-600 focus:ring-offset-2 focus:ring-offset-gray-900 rounded px-2 py-1 motion-reduce:transition-none">
                    Termos de Uso
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-teal-400 transition focus:outline-none focus:ring-2 focus:ring-teal-600 focus:ring-offset-2 focus:ring-offset-gray-900 rounded px-2 py-1 motion-reduce:transition-none">
                    Privacidade
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-teal-400 transition focus:outline-none focus:ring-2 focus:ring-teal-600 focus:ring-offset-2 focus:ring-offset-gray-900 rounded px-2 py-1 motion-reduce:transition-none">
                    Cookies
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-teal-400 transition focus:outline-none focus:ring-2 focus:ring-teal-600 focus:ring-offset-2 focus:ring-offset-gray-900 rounded px-2 py-1 motion-reduce:transition-none">
                    FAQ
                  </a>
                </li>
              </ul>
            </div>
          </div>

          {/* Footer Bottom */}
          <div className="border-t border-gray-800 pt-8 text-center text-gray-400">
            <p>&copy; 2024 CarePaw. Projeto acadêmico - Centro Universitário de Brasília (CEUB)</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
